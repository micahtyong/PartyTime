delete from party;
delete from rating;
delete from invite_lst;
delete from invite;
delete from user;
delete from frat;
